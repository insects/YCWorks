//
//  YCTexturedButton.h
//  iAlarm
//
//  Created by li shiyong on 12-5-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YCFixedImageButton.h"

@interface YCTexturedButton : YCFixedImageButton

@end
