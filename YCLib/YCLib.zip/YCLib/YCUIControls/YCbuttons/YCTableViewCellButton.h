//
//  YCTableViewCellButton.h
//  iAlarm
//
//  Created by li shiyong on 12-7-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "YCFixedImageButton.h"

@interface YCTableViewCellButton : YCFixedImageButton

@end
