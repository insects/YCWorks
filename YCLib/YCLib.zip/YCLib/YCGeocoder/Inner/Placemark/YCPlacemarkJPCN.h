//
//  YCPlacemarkJP.h
//  iAlarm
//
//  Created by li shiyong on 12-5-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "YCPlacemark.h"

@interface YCPlacemarkJPCN : YCPlacemark

@end
