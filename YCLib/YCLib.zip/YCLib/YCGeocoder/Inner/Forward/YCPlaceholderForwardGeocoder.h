//
//  YCPlaceholderForwardGeocoder.h
//  iAlarm
//
//  Created by li shiyong on 12-6-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "YCForwardGeocoder.h"

@interface YCPlaceholderForwardGeocoder : YCForwardGeocoder

@end
