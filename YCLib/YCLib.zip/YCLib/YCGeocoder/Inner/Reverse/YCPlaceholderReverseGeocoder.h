//
//  YCPlacehoderGeocoder.h
//  iAlarm
//
//  Created by li shiyong on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "YCReverseGeocoder.h"

@interface YCPlaceholderReverseGeocoder : YCReverseGeocoder


@end
