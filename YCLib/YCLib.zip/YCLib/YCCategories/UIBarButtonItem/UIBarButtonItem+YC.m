//
//  UIBarButtonItem+YC.m
//  iAlarm
//
//  Created by li shiyong on 12-8-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIBarButtonItem+YC.h"

@implementation UIBarButtonItem (YC)

@end
