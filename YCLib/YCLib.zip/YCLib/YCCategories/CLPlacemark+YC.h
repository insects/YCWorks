//
//  CLPlacemark+YC.h
//  iAlarm
//
//  Created by li shiyong on 12-5-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>

@interface CLPlacemark (YC)

- (NSString *)description;

@end
