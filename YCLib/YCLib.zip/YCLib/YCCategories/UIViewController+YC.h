//
//  UIViewController+YC.h
//  iAlarm
//
//  Created by li shiyong on 12-5-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (YC)

- (BOOL)isViewAppeared;

@end
