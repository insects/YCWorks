//
//  UIColor+YC.m
//  iAlarm
//
//  Created by li shiyong on 12-4-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIColor+YC.h"

@implementation UIColor (YC)

- (UIColor *)initWithIntRed:(NSInteger)intRed intGreen:(NSInteger)intGreen intBlue:(NSInteger)intBlue intAlpha:(NSInteger)intAlpha{
    return [self initWithRed:intRed/255.0f green:intGreen/255.0f blue:intBlue/255.0f alpha:intAlpha/255.0f];
}

+ (UIColor *)colorWithIntRed:(NSInteger)intRed intGreen:(NSInteger)intGreen intBlue:(NSInteger)intBlue intAlpha:(NSInteger)intAlpha{
    return [[[UIColor alloc] initWithIntRed:intRed intGreen:intGreen intBlue:intBlue intAlpha:intAlpha] autorelease];
}

+ (UIColor *)darkBackgroundColor{
    return [UIColor colorWithRed:151.0/255.0 green:152.0/255.0 blue:155.0/255.0 alpha:1.0];
}

+ (UIColor *)lightBackgroundColor{
    return [UIColor colorWithRed:172.0/255.0 green:173.0/255.0 blue:175.0/255.0 alpha:1.0];
}

+ (UIColor *)tableCellBlueTextYCColor{
    return [UIColor colorWithRed:0.22 green:0.33 blue:0.53 alpha:1.0];
}

+ (UIColor *)tableViewFooterTextColor{
    return [UIColor colorWithRed:76.0/255.0 green:86.0/255.0 blue:108.0/255.0 alpha:1.0];
}

+ (UIColor *)tableViewFooter2TextColor{
    return [UIColor colorWithRed:37.0/255.0 green:50.0/255.0 blue:67.0/255.0 alpha:1.0];
}

+ (UIColor *)textShadowColor{
    return [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1.0];
}

+ (UIColor *)texturedButtonGradientColor{
    return [UIColor colorWithPatternImage:[UIImage imageNamed:@"YCTexturedButtonTextGradient.png"]];
}

+ (UIColor *)texturedButtonGradientSmallColor{
    return [UIColor colorWithPatternImage:[UIImage imageNamed:@"YCTexturedButtonTextGradientSmall.png"]];
}

+ (UIColor *)mapsMaskColor{
    return [UIColor colorWithIntRed:179 intGreen:177 intBlue:173 intAlpha:255];
}

+ (UIColor *)tableCellGrayTextYCColor{
    return [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0];
}
/*
+ (UIColor *)iPadGroupTableViewBackgroundColor{
    return [UIColor colorWithPatternImage:[UIImage imageNamed:@"YCiPadGroupTableViewBackgroundColor.png"]];
}
 */

+ (UIColor *)iPadTableCellGroupedBackgroundColor{
    return [UIColor colorWithRed:0.97 green:0.97 blue:0.97 alpha:1.0];
}

+ (UIColor *)tableViewBackgroundViewBackgroundColor{
    return [self colorWithIntRed:92 intGreen:99 intBlue:103 intAlpha:255];
}

+ (UIColor *)underPageBackgroundYCColor{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] > 4.9) {// iOS 5.0 才有 underPageBackgroundColor
        return [UIColor underPageBackgroundColor];
    }else {
        return [UIColor colorWithPatternImage:[UIImage imageNamed:@"YCStockImageUnderPageBackground.png"]];
    }
}

+ (UIColor *)groupTableViewBackgroundColor1{
    return [UIColor colorWithPatternImage:[UIImage imageNamed:@"YCGroupTableViewBackgroundColor1.png"]];
}


+ (UIColor *)switchBlue{
    return [self colorWithIntRed:0 intGreen:127 intBlue:234 intAlpha:255];
}

+ (UIColor *)navigationBarSilverTitleColor{
    return [self colorWithIntRed:113 intGreen:120 intBlue:128 intAlpha:255];
}


@end
