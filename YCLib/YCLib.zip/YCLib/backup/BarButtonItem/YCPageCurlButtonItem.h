//
//  YCPageCulButtonItem.h
//  iAlarm
//
//  Created by li shiyong on 11-2-9.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "YCBarButtonItem.h"
#import <Foundation/Foundation.h>

@interface YCPageCurlButtonItem : YCBarButtonItem {

}

@end
