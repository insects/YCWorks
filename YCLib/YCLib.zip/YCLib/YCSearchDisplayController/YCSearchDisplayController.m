//
//  YCSearchDisplayController.m
//  testNavC
//
//  Created by li shiyong on 12-8-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UISearchBar+YC.h"
#import "YCSearchDisplayController.h"

@interface YCSearchDisplayController ()

@end

@implementation YCSearchDisplayController
@synthesize active = _active, delegate = _delegate, contentsController = _contentsController, searchBar = _searchBar;
@synthesize searchResultsTableView = _searchResultsTableView, searchResultsDataSource = _searchResultsDataSource, searchResultsDelegate = searchResultsDelegate;



- (void)setActive:(BOOL)active animated:(BOOL)animated{
    if (_active == active) 
        return;
    _active = active;

    
    UINavigationController *navController = _contentsController.navigationController;
    UINavigationItem *navigationItem =  _contentsController.navigationItem;
    UINavigationBar *navBar = _contentsController.navigationController.navigationBar;
    BOOL searchBarInNavBar = (_searchBar == navigationItem.titleView);//searchBar是否在navBar中
    NSTimeInterval duration = animated ? 0.25 : 0.0;
        
    //cancel 按钮
    [_searchBar setShowsCancelButton:active animated:animated];
    
    //navBar
    if (!searchBarInNavBar) {
        [navController setNavigationBarHidden:active animated:animated];
    }else {
        if (active) {
            [_leftItemOfNavBar release];
            [_rightItemOfNavBar release];
            _leftItemOfNavBar = [navigationItem.leftBarButtonItem retain];
            _rightItemOfNavBar = [navigationItem.rightBarButtonItem retain];
            [navigationItem setLeftBarButtonItem:nil animated:animated];
            [navigationItem setRightBarButtonItem:nil animated:animated];
            
            
            //解决titleView在有rightBarButtonItem或leftBarButtonItem的时候不拉伸到尽头
            CGRect titleViewFrame = CGRectInset(navBar.bounds, 5, 0);
            [UIView transitionWithView:navBar duration:duration -0.1 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{
                navigationItem.titleView.frame = titleViewFrame;
            } completion:NULL];
            
            
        }else {
            [navigationItem setLeftBarButtonItem:_leftItemOfNavBar animated:animated];
            [navigationItem setRightBarButtonItem:_rightItemOfNavBar animated:animated];
        }
        
    }

    
    //淡黑的视图
    [UIView transitionWithView:_contentsController.view duration:duration options:UIViewAnimationOptionTransitionCrossDissolve animations:^{
        if (active) {
            //_dimmingView的Frame = _searchBar向下偏移
            CGRect searchBarFrame = [_contentsController.view convertRect:_searchBar.frame fromView:_searchBar.superview];
            CGRect dimmingViewFrame = CGRectOffset(_contentsController.view.bounds, 0.0, searchBarFrame.origin.y + searchBarFrame.size.height);
            _dimmingView.frame = dimmingViewFrame;
            
            [_contentsController.view addSubview:_dimmingView];
        }else {
            [_dimmingView removeFromSuperview];
        } 
    } completion:NULL];
    
    
    //
    if (active) 
        [_searchBar becomeFirstResponder];
    else 
        [_searchBar resignFirstResponder];

    //delegate
    if (!active) {
        if ([_delegate respondsToSelector:@selector(searchDisplayControllerDidEndSearch:)]) {
            [_delegate searchDisplayControllerDidEndSearch:self];
        }
    }
     
}

- (void)setActive:(BOOL)active{
    [self setActive:active animated:NO];
}

- (id)initWithSearchBar:(UISearchBar *)searchBar contentsController:(UIViewController *)viewController{
    self = [super init];
    if (self) {        
        _searchBar = [searchBar retain];
        _contentsController = [viewController retain];
        _searchBar.textField.delegate = self;
        
        //
        CGRect dimmingViewFrame = _contentsController.view.bounds;
        _dimmingView = [[UIControl alloc] initWithFrame:dimmingViewFrame];
        _dimmingView.backgroundColor = [UIColor colorWithWhite:0.03 alpha:0.85];
        [(UIControl*)_dimmingView addTarget:self action:@selector(dimmingViewTapped:) forControlEvents:UIControlEventTouchUpInside];
        
        //
        CGRect tableViewFrame = _contentsController.view.bounds;
        tableViewFrame = CGRectOffset(tableViewFrame, 0.0, _searchBar.bounds.size.height);
        _searchResultsTableView = [[UITableView alloc] initWithFrame:tableViewFrame style:UITableViewStylePlain];
        
    }
    return self;
}

#pragma mark - 

- (void)dimmingViewTapped:(id)sender{
    [self setActive:NO animated:YES];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self setActive:YES animated:YES];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSLog(@"string = %@",string);
    [_searchResultsTableView reloadData];
    
    [UIView transitionWithView:_contentsController.view duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{
        if ([_searchResultsTableView numberOfRowsInSection:0] > 0) {
            [_contentsController.view addSubview:_searchResultsTableView];
        }else {
            [_searchResultsTableView removeFromSuperview];
        }
    } completion:NULL];
    
    return YES;
}

- (void)dealloc{
    [_contentsController release];
    [_searchResultsTableView release];
    [_searchBar release];
    [_leftItemOfNavBar release];
    [_rightItemOfNavBar release];
    [super dealloc];
}

@end
